from pydantic import BaseModel
from typing import List, Dict, Any, Optional


class ESGNews(BaseModel):
    """Extended news model with ESG-specific fields"""
    ticker: str
    title: str
    author: str
    source: str
    date: str
    url: str
    sentiment_score: float  # Numerical score from -1 to +1
    esg_category: str  # Environmental, Social, or Governance
    relevance_score: int  # 0-10 scale
    excerpt: str  # Article excerpt or summary
    is_regulatory_filing: bool = False  # Whether it's related to a regulatory filing


class ESGCompositeScore(BaseModel):
    """Daily composite ESG score with alpha signal"""
    date: str
    composite_esg_score: float  # 0-100 normalized score
    z_score: float  # 5-day rolling Z-score
    alpha_signal: str  # Buy/Sell/Neutral
    key_event_summary: str  # Summary of key events for the day


class ESGAnalysis(BaseModel):
    """Complete ESG analysis results"""
    signal: str  # Overall signal (bullish/bearish/neutral)
    confidence: int  # Confidence level (0-100)
    reasoning: str  # Explanation of the analysis
    esg_data: List[ESGCompositeScore]  # Daily ESG scores and signals
    top_drivers: List[str]  # Summary of top ESG drivers