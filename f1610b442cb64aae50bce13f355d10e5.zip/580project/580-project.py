#%% Import 
import yfinance as yf
import pandas as pd
import numpy as np
from ta.trend import MACD
from ta.momentum import RSIIndicator
from ta.momentum import StochasticOscillator
from ta.volatility import BollingerBands
from ta.volatility import AverageTrueRange
from ta.volume import OnBalanceVolumeIndicator
import matplotlib.pyplot as plt
import pprint

#%% Initialize state
state = {
    # Ticker symbol for the asset to trade (default is "NVDA")
    "tic": "NVDA",
    
    "src_dir" : r"C:\Users\liang\OneDrive\Desktop\580project",
     
    
    # DataFrame to store technical indicators
    "indicators": pd.DataFrame(),  
    
    # Trading signal (possible values: BUY, SELL, HOLD)
    "trading_signal": None,  
    
    # Confidence level of the trading signal
    "signal_confidence": None,  
        
    # Risk level associated with the trade
    "risk_level": None,  
    
    # Initial account balance
    "account_balance": 100000,  
    
    # Trade amount or position size in monetary terms
    "position_size": None,  
    
    # Number of shares or units to trade
    "position_units": None,  
    
    # Dictionary to store current portfolio holdings
    "portfolio": {},  
    
    # List to store trade history
    "trade_history": [],  
    
    # Current trade status (e.g., active, closed)
    "trade_status": None,  
    
    "esg_signals": {}, 
    
    #Backtest Performance Summary
    "performance": None
    
}
#%%DataCollectionAgent
class DataCollectionAgent:
    def run(self, state):
        # Get the ticker symbol from the state, defaulting to "NVDA" if not provided
        tic = state.get("tic", "NVDA")  
        
        # Define the benchmark symbol for S&P 500
        benchmark_symbol = "^GSPC"  # S&P 500
        

        # Fetch daily market data for the past 3 years for the specified ticker
        daily_data = yf.Ticker(tic).history(period="3y", interval="1d")
        
        # Fetch daily benchmark data for the past 3 years for the S&P 500 index
        benchmark_data = yf.Ticker(benchmark_symbol).history(period="3y", interval="1d")
        
        # Store the fetched data in the state dictionary for further use
            
        state["daily_data"] = daily_data        
        state["benchmark_data"] = benchmark_data  
        
        # Print the first few rows of each dataset for verification purposes
        print(state["daily_data"].head())
        print(state["benchmark_data"].head())
#%%
daily_data = pd.read_csv('GSPC_daily_data.csv',index_col=0,date_parser=True)



# Fetch daily benchmark data for the past 3 years for the S&P 500 index
benchmark_data = yf.Ticker(benchmark_symbol).history(period="3y", interval="1d")

# Store the fetched data in the state dictionary for further use
    
state["daily_data"] = daily_data        
state["benchmark_data"] = benchmark_data  
#%% DataAnalysisAgent
class DataAnalysisAgent:
    
    def run(self, state):
        tic = state.get("tic", "NVDA") 
        daily_data = state.get("daily_data", pd.DataFrame()).copy()
        benchmark_data = state.get("benchmark_data", pd.DataFrame()).copy()
        if daily_data.empty:
            print("daily_data  empty")
            return
        
        indicators = pd.DataFrame()
        ##SMA
        indicators["sma_50"] = daily_data["Close"].rolling(window=50).mean()
        indicators["sma_200"] = daily_data["Close"].rolling(window=200).mean()
        ##EMA
        indicators["ema_20"] = daily_data["Close"].ewm(span=20, adjust=False).mean()
        indicators["ema_50"] = daily_data["Close"].ewm(span=50, adjust=False).mean()
        ##MACD
        macd_indicator = MACD(close=daily_data["Close"], window_slow=26, window_fast=12, window_sign=9)
        indicators["macd_line"] = macd_indicator.macd()
        indicators["macd_signal"] = macd_indicator.macd_signal()
        indicators["macd_histogram"] = macd_indicator.macd_diff()
        ##RSI_14
        indicators["rsi_14"] = RSIIndicator(daily_data["Close"], window=14).rsi()
        ##stochastic
        stoch = StochasticOscillator(
            high=daily_data["High"],
            low=daily_data["Low"],
            close=daily_data["Close"],
            window=14,
            smooth_window=3,
            fillna=False
            )
        indicators["stochastic_k"] = stoch.stoch()
        indicators["stochastic_d"] = stoch.stoch_signal()
        ##bollinger
        bollinger = BollingerBands(
            close=daily_data["Close"],
            window=20, 
            window_dev=2.0,
            fillna=False
            )
        indicators["bollinger_upper"] = bollinger.bollinger_hband()
        indicators["bollinger_middle"] = bollinger.bollinger_mavg()
        indicators["bollinger_lower"] = bollinger.bollinger_lband()
        ##Average true range
        atr = AverageTrueRange(
            high=daily_data["High"],
            low=daily_data["Low"],
            close=daily_data["Close"],
            window=14,
            fillna=False
            )
        indicators["atr_14"] = atr.average_true_range()
        ##obv
        obv_indicator = OnBalanceVolumeIndicator(
            close=daily_data["Close"],
            volume=daily_data["Volume"],
            fillna=False
            )
        indicators["obv"] = obv_indicator.on_balance_volume()
        ##beta
        daily_data = daily_data.sort_index()
        benchmark_data = benchmark_data.sort_index()
        nvda_returns = daily_data["Close"].pct_change()
        sp500_returns = benchmark_data["Close"].pct_change()
        sp500_returns = sp500_returns.reindex(nvda_returns.index, method="ffill")
        window = 60
        rolling_corr = nvda_returns.rolling(window).corr(sp500_returns)
        rolling_std_nvda = nvda_returns.rolling(window).std()
        rolling_std_sp500 = sp500_returns.rolling(window).std()
        rolling_beta = rolling_corr * (rolling_std_nvda / rolling_std_sp500)
        indicators["beta"] = rolling_beta
        ##Benchmark
        indicators["benchmark"] = benchmark_data["Close"].reindex(indicators.index, method="ffill")
        
        state["indicators"]=indicators
        print(state["indicators"].head())


#%%
# Add the project root directory to Python path
import os
import sys

src_dir=state.get("src_dir", r"C:\Users\liang\OneDrive\Desktop\580project")
sys.path.insert(0, src_dir)

# Now we can import from the agents directory using absolute imports
from agents.esg_news import esg_news_agent
from graph.state import AgentState
from data.models import Portfolio
from tools.esg_news_api import get_esg_news, analyze_esg_sentiment, get_api_key

# Check if API key is set
def check_api_key():
    """Check if NewsAPI key is set and provide instructions if not"""
    api_key = get_api_key()
    if not api_key:
        print("\nERROR: NewsAPI key is not set. Please set your API key using one of these methods:")
        print("1. Set the NEWS_API_KEY environment variable:")
        print("   - For macOS/Linux: export NEWS_API_KEY=your_api_key_here")
        print("   - For Windows: set NEWS_API_KEY=your_api_key_here")
        print("2. Or edit the esg_news_api.py file to set the default API key")
        print("\nYou can get a free API key at https://newsapi.org/register")
        return False
    return True

# 在这里修改您想要分析的股票代码和日期范围
# 您可以直接修改以下变量的值，而不需要通过命令行参数
DEFAULT_TICKER = state.get("tic", "NVDA")   # 股票代码，例如：AAPL（苹果）、MSFT（微软）、TSLA（特斯拉）等
DEFAULT_START_DATE = "2025-04-05"  # 开始日期，格式：YYYY-MM-DD
DEFAULT_END_DATE = "2025-05-02"  # 结束日期，格式：YYYY-MM-DD

# Example usage
def run_esg_agent(use_direct_api=False, export_csv=True, output_dir=None, start_date=DEFAULT_START_DATE, end_date=DEFAULT_END_DATE, ticker=DEFAULT_TICKER):
    print("Running ESG News Agent...")
    
    # 允许用户自定义时间范围，如果未提供则使用默认值
    from datetime import datetime, timedelta
    
    # 如果未提供日期，则使用默认值（使用上面设置的DEFAULT_START_DATE和DEFAULT_END_DATE）
    # 注意：这里的None或空字符串检查是为了处理命令行参数未提供的情况
    # 在main函数中已经确保了传入的start_date和end_date要么是用户指定的值，要么是DEFAULT值
    # 这里只需要处理空字符串的情况
    if end_date == "":
        end_date = DEFAULT_END_DATE
    if start_date == "":
        start_date = DEFAULT_START_DATE
    
    print(f"使用时间范围: {start_date} 到 {end_date}")
    # Note: Free NewsAPI plan has very limited historical access
    
    state = AgentState(
        messages=[],
        data={
            "tickers": [ticker],
            "start_date": start_date,  # 使用用户提供的开始日期
            "end_date": end_date,      # 使用用户提供的结束日期
            "portfolio": Portfolio(positions={}, total_cash=1000000.0),
            "analyst_signals": {},
        },
        metadata={
            "show_reasoning": True,
            "model_name": "gpt-4",
            "model_provider": "openai",
        },
    )
    
    # First check if API key is set
    if not check_api_key():
        print("\nCannot proceed without a valid API key.")
        return
        
    # Create output directory for CSV files if specified
    if export_csv and output_dir:
        os.makedirs(output_dir, exist_ok=True)
        csv_news_path = os.path.join(output_dir, f"{ticker}_esg_news.csv")
        csv_sentiment_path = os.path.join(output_dir, f"{ticker}_esg_sentiment.csv")
    else:
        csv_news_path = f"{ticker}_esg_news.csv"
        csv_sentiment_path = f"{ticker}_esg_sentiment.csv"
    
    try:
        if use_direct_api:
            # Use the direct API approach instead of the agent
            print(f"Fetching ESG news for {ticker} from {start_date} to {end_date}...")
            try:
                news_items = get_esg_news(
                    ticker=ticker,
                    start_date=start_date,
                    end_date=end_date,
                    export_csv=export_csv,
                    csv_filename=csv_news_path
                )
                
                if news_items:
                    print(f"Found {len(news_items)} ESG-related news items")
                    # 为每日ESG得分创建CSV路径
                    csv_daily_scores_path = os.path.join(output_dir, f"{ticker}_daily_esg_scores.csv") if output_dir else f"{ticker}_daily_esg_scores.csv"
                    
                    sentiment_results = analyze_esg_sentiment(
                        news_items=news_items,
                        export_csv=export_csv,
                        csv_filename=csv_sentiment_path,
                        daily_scores_csv=csv_daily_scores_path
                    )
                    print(f"\nESG情感分析结果:")
                    print(f"总体得分: {sentiment_results['score']:.2f}/10")
                    print(f"详情: {sentiment_results['details']}")
                    
                    # 显示每日ESG得分信息
                    if 'daily_scores' in sentiment_results and sentiment_results['daily_scores']:
                        print(f"\n每日ESG得分 (用于α信号):")
                        print("-" * 50)
                        print(f"{'日期':<12}{'ESG得分':<10}")
                        print("-" * 50)
                        
                        # 按日期排序显示每日得分
                        for date in sorted(sentiment_results['daily_scores'].keys()):
                            score = sentiment_results['daily_scores'][date]
                            print(f"{date:<12}{score:.2f}")
                        
                        print(f"\n每日ESG得分已导出到: {csv_daily_scores_path}")
                    else:
                        print("\n没有可用的每日ESG得分数据")
                else:
                    print("No ESG news found for the specified time range.")
                    print("Try expanding the date range or using a different ticker.")
            except Exception as api_error:
                print(f"Error fetching or processing news: {api_error}")
                print("\nPossible solutions:")
                print("1. Check your internet connection")
                print("2. Verify the API key is correct")
                print("3. The free NewsAPI plan has very limited historical access (usually only the last month)")
                print("4. Try using a different ticker with more news coverage")
        else:
            # Run the full ESG news agent
            print("Running ESG news analysis through agent...")
            result = esg_news_agent(state)
            
            # Access results
            if "analyst_signals" in result["data"] and "esg_news_agent" in result["data"]["analyst_signals"]:
                esg_analysis = result["data"]["analyst_signals"]["esg_news_agent"][ticker]
                print(f"\nESG Analysis Results:")
                print(f"Signal: {esg_analysis['signal']}")
                print(f"Confidence: {esg_analysis['confidence']}%")
                print(f"Reasoning: {esg_analysis['reasoning']}")
            else:
                print("\nESG analysis completed but no signals were generated.")
                print("This may be due to missing API credentials or insufficient data.")
    
    except Exception as e:
        print(f"Error running ESG News Agent: {str(e)}")
        print("\nNote: This may be due to missing API credentials or dependencies.")
        print("Try running the mock demo instead: python src/demo_esg_nvidia_mock.py")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run ESG News Analysis for NVIDIA")
    parser.add_argument("--use-agent", action="store_true", help="Use the full agent instead of direct API")
    parser.add_argument("--no-csv", action="store_true", help="Disable CSV export")
    parser.add_argument("--output-dir", type=str, help="Directory to save CSV files")
    parser.add_argument("--ticker", type=str, default="NVDA", help="Stock ticker symbol (default: NVDA)")
    parser.add_argument("--start-date", type=str, help="Start date in YYYY-MM-DD format")
    parser.add_argument("--end-date", type=str, help="End date in YYYY-MM-DD format")
    
    args = parser.parse_args()
    
    # 只有当命令行参数明确提供时才使用它们，否则使用默认值
    start_date = args.start_date if args.start_date is not None else DEFAULT_START_DATE
    end_date = args.end_date if args.end_date is not None else DEFAULT_END_DATE
    
    # Run with parsed arguments
    run_esg_agent(
        use_direct_api=not args.use_agent,  # Default is direct API unless --use-agent is specified
        export_csv=not args.no_csv,         # Default is to export CSV unless --no-csv is specified
        output_dir=args.output_dir,         # Optional output directory
        start_date=start_date,              # 使用处理后的开始日期
        end_date=end_date,                  # 使用处理后的结束日期
        ticker=args.ticker                  # Optional ticker symbol
    )

tic = state.get("tic", "NVDA")    
ticker = state.get("tic", "NVDA")    
csv_path = f"{tic}_daily_esg_scores.csv" # 如果你没有指定 output_dir，可改成 f"{ticker}_daily_esg_scores.csv"
df_esg = pd.read_csv(csv_path, parse_dates=['date'])

# 假设 CSV 长这样：date,score
# 如果列名不是 score，请改成实际列名
# … 你已有的代码 …
df_esg.rename(columns={df_esg.columns[1]: 'esg_score'}, inplace=True)

# 定义从 0–10 分到信号/置信度的映射
def map_signal(esg_score):
    if esg_score >= 7:
        return "BUY"
    elif esg_score <= 3:
        return "SELL"
    else:
        return "NEUTRAL"

# 构造 date→{signal,confidence} 的字典
esg_dict = {}
for _, row in df_esg.iterrows():
    date_str = row['date'].strftime('%Y-%m-%d')
    sig = map_signal(row['esg_score'])
    conf = abs(row['esg_score'] - 5) / 5
    esg_dict[date_str] = {"signal": sig, "confidence": conf}

# **关键：** 外层加上 ticker 这一层
state["esg_signals"] = {
    ticker: esg_dict
}

# （可选）保留 DataFrame，便于调试或可视化
state["esg_signals_df"] = df_esg.set_index('date')

    
#%% StrategyDevelopmentAgent
import pandas as pd
import numpy as np

class StrategyDevelopmentAgent:
    """
    Enhanced Strategy Agent integrating ESG News signals
    ----------------------------------------------------
    *Original functionality*
        - Generates BUY / SELL / HOLD signals from technical indicators.
    *New functionality*
        - Consumes ESG News Agent output (Buy / Sell / Neutral + confidence 0‑1)
          and blends it with the technical rule‑set.
    Expected ESG input locations in **state** (either one works):
        1. state["esg_signals"] → dict
        2. state["data"]["analyst_signals"]["esg_news_agent"] → dict

    Accepted schema (flexible):
        {ticker: {
            "YYYY‑MM‑DD": {"signal":"BUY","confidence":0.8},
            ...
        }}
        ‑ or ‑
        {ticker: {"signal":"BUY","confidence":0.8,"date":"YYYY‑MM‑DD"}}

    The ESG signal of the *current day* is incorporated as an extra BUY/SELL
    condition worth **+1** (confidence ≥ 0.6) or **+0.5** (confidence < 0.6).
    """

    def run(self, state):
        tic = state.get("tic", "NVDA")
        print("Generating trading signals with ESG overlay…")

        # --- Retrieve price & technical data
        indicators = state.get("indicators", pd.DataFrame()).copy()
        daily_data = state.get("daily_data", pd.DataFrame()).copy()
        if indicators.empty or daily_data.empty:
            print("Missing technical indicators or daily data → abort")
            return

        # --- Retrieve ESG News signals -------------------------------------
        esg_raw = state.get("esg_signals", None)
        if esg_raw is None:
            esg_raw = (state.get("data", {})
                            .get("analyst_signals", {})
                            .get("esg_news_agent", {}))

        esg_df = pd.DataFrame()
        if isinstance(esg_raw, dict) and tic in esg_raw:
            inner = esg_raw[tic]
            records = []
            # layout A: nested by date
            for k, v in inner.items():
                if isinstance(v, dict) and "signal" in v:
                    records.append({
                        "date": pd.to_datetime(k),
                        "signal": v["signal"].upper(),
                        "confidence": float(v.get("confidence", 1.0))
                    })
            # layout B: single latest record
            if not records and "signal" in inner:
                records.append({
                    "date": pd.to_datetime(inner.get("date", indicators.index[-1])),
                    "signal": inner["signal"].upper(),
                    "confidence": float(inner.get("confidence", 1.0))
                })
            if records:
                esg_df = pd.DataFrame(records).set_index("date")

        # --------------------------------------------------------------------

        # Initialise columns
        indicators[[
            "trading_signal", "signal_confidence",
            "stop_loss_price", "take_profit_price", "risk_level"
        ]] = ["HOLD", 50, np.nan, np.nan, "LOW"]
        indicators["signal_reasons"] = None

        all_signal_reasons = []

        for i in range(1, len(indicators)):
            # --- Skip if critical indicators are nan -----------------------
            required_cols = ["sma_50", "sma_200", "rsi_14", "macd_line", "macd_signal"]
            if indicators.iloc[i][required_cols].isna().any():
                continue

            current_date = indicators.index[i]
            if current_date not in daily_data.index:
                continue

            current_price = daily_data.loc[current_date, "Close"]
            sma_50 = indicators.loc[current_date, "sma_50"]
            sma_200 = indicators.loc[current_date, "sma_200"]
            rsi_14 = indicators.loc[current_date, "rsi_14"]
            macd_line = indicators.loc[current_date, "macd_line"]
            macd_signal = indicators.loc[current_date, "macd_signal"]
            bollinger_upper = indicators.loc[current_date, "bollinger_upper"]
            bollinger_lower = indicators.loc[current_date, "bollinger_lower"]
            atr_14 = indicators.loc[current_date, "atr_14"]

            signal_reasons = []

            # --- Trend determination (unchanged) ---------------------------
            trend = "uptrend" if current_price > sma_200 else "downtrend"
            signal_reasons.append(
                "Price above 200‑day SMA, uptrend confirmed" if trend == "uptrend"
                else "Price below 200‑day SMA, downtrend confirmed"
            )

            buy_cond = 0.0
            sell_cond = 0.0

            # Technical BUY conditions
            if trend == "uptrend" and 0.99 * sma_50 <= current_price <= 1.01 * sma_50:
                buy_cond += 1
                signal_reasons.append("Price near 50‑day SMA support")
            if rsi_14 < 40 and rsi_14 > indicators["rsi_14"].iloc[i - 1]:
                buy_cond += 1
                signal_reasons.append("RSI < 40 and rising")
            if macd_line > macd_signal and indicators["macd_line"].iloc[i - 1] <= indicators["macd_signal"].iloc[i - 1]:
                buy_cond += 1
                signal_reasons.append("MACD golden cross")
            if current_price < bollinger_lower * 1.02:
                buy_cond += 1
                signal_reasons.append("Price near lower Bollinger")

            # Technical SELL conditions
            if trend == "downtrend" and current_price < sma_50:
                sell_cond += 1
                signal_reasons.append("Price breaks 50‑day SMA support")
            if rsi_14 > 70 and rsi_14 < indicators["rsi_14"].iloc[i - 1]:
                sell_cond += 1
                signal_reasons.append("RSI > 70 and falling")
            if macd_line < macd_signal and indicators["macd_line"].iloc[i - 1] >= indicators["macd_signal"].iloc[i - 1]:
                sell_cond += 1
                signal_reasons.append("MACD death cross")
            if current_price > bollinger_upper * 0.98:
                sell_cond += 1
                signal_reasons.append("Price near upper Bollinger")

            # --- ESG overlay ----------------------------------------------
            news_signal = "NEUTRAL"
            news_conf = 0.0
            if not esg_df.empty and current_date in esg_df.index:
                news_signal = esg_df.loc[current_date, "signal"]
                news_conf = esg_df.loc[current_date, "confidence"]

            if news_signal == "BUY":
                inc = 1 if news_conf >= 0.6 else 0.5
                buy_cond += inc
                signal_reasons.append(f"ESG News BUY ({news_conf:.0%} conf.)")
            elif news_signal == "SELL":
                inc = 1 if news_conf >= 0.6 else 0.5
                sell_cond += inc
                signal_reasons.append(f"ESG News SELL ({news_conf:.0%} conf.)")
            # NEUTRAL does nothing

            # --- Decision logic (thresholds include potential 0.5 steps) ---
            if buy_cond >= 2 and buy_cond > sell_cond:
                trading_signal = "BUY"
                signal_confidence = min(int(buy_cond * 25), 100)
            elif sell_cond >= 2 and sell_cond > buy_cond:
                trading_signal = "SELL"
                signal_confidence = min(int(sell_cond * 25), 100)
            else:
                trading_signal = "HOLD"
                signal_confidence = 50

            # Risk management
            if trading_signal == "BUY":
                stop_loss = current_price - 2 * atr_14
                take_profit = current_price + 3 * atr_14
                risk_level = "MEDIUM"
            elif trading_signal == "SELL":
                stop_loss = current_price + 2 * atr_14
                take_profit = current_price - 3 * atr_14
                risk_level = "MEDIUM"
            else:
                stop_loss = np.nan
                take_profit = np.nan
                risk_level = "LOW"

            # Write back
            indicators.loc[current_date, [
                "trading_signal", "signal_confidence",
                "stop_loss_price", "take_profit_price", "risk_level",
                "signal_reasons"
            ]] = [trading_signal, signal_confidence,
                  round(stop_loss, 2) if not pd.isna(stop_loss) else np.nan,
                  round(take_profit, 2) if not pd.isna(take_profit) else np.nan,
                  risk_level, "; ".join(signal_reasons)]

            all_signal_reasons.append({"date": current_date, "reasons": signal_reasons})

        # --- Persist back to state ----------------------------------------
        start_date = pd.to_datetime("2025-04-10")
        indicators = indicators.loc[indicators.index >= start_date]


        state["indicators"] = indicators
        state["signal_reasons_history"] = all_signal_reasons

        if not indicators.empty:
            latest_idx = indicators.index[-1]
            last_row = indicators.loc[latest_idx]
            state.update({
                "trading_signal": last_row["trading_signal"],
                "signal_confidence": last_row["signal_confidence"],
                "stop_loss_price": last_row["stop_loss_price"],
                "take_profit_price": last_row["take_profit_price"],
                "risk_level": last_row["risk_level"],
                "signal_reasons": last_row["signal_reasons"].split("; ") if isinstance(last_row["signal_reasons"], str) else []
            })

        # --- Simple stats --------------------------------------------------
        print("Backtest complete → ESG overlay active")
        print("BUY  signals:", (indicators["trading_signal"] == "BUY").sum())
        print("SELL signals:", (indicators["trading_signal"] == "SELL").sum())
        print("HOLD signals:", (indicators["trading_signal"] == "HOLD").sum())
        print(f"Latest: {state.get('trading_signal')} @ {state.get('signal_confidence')}% conf.")


#%%
class PortfolioManagementAgent:
    """Portfolio Management Agent:
    
    This agent dynamically updates the account balance and positions,
    while calculating the position sizing at each time point.
    On trading days, it checks if the preset stop loss or take profit prices are hit 
    based on the daily price range, in order to determine the actual execution price.
    After all trades are completed, it saves the trade records into state["trade_history"].
    Profit and loss (profit) information is calculated and recorded during SELL operations.
    """

    def run(self, state):
        # Retrieve ticker symbol from state, defaulting to "NVDA" if not provided.
        tic = state.get("tic", "NVDA")
        print("Calculating dynamic position sizing and updating trading account with stop loss/take profit execution...")

        # Retrieve daily price data and technical indicators from state.
        daily_data = state.get("daily_data", pd.DataFrame())
        indicators = state.get("indicators", pd.DataFrame()).copy()
        # Check if either daily data or indicators are empty, and exit if so.
        if daily_data.empty or indicators.empty:
            print("daily_data or indicators is empty, cannot compute dynamic position sizing.")
            return

        # Ensure the indicators DataFrame is sorted by date.
        indicators = indicators.sort_index()
        # Initialize account balance and portfolio holdings (using NVDA as an example).
        account_balance = state.get("account_balance", 100000)
        portfolio = state.get("portfolio", {})  # For example: {tic: number of shares held, "avg_cost": average cost}

        # Define a risk mapping: risk levels to the percentage of account balance to risk.
        risk_map = {"LOW": 0.01, "MEDIUM": 0.02, "HIGH": 0.03}

        # Initialize a list to store trading records at each time point.
        records = []
        
        # Iterate through each time point (date) in the indicators DataFrame
        for date, row in indicators.iterrows():
            # Check if daily_data contains the current date; if not, skip to the next date
            if date not in daily_data.index:
                continue

            # Retrieve the closing, high, and low prices for the current date from daily_data
            current_price = daily_data.loc[date, "Close"]
            daily_high = daily_data.loc[date, "High"]
            daily_low = daily_data.loc[date, "Low"]

            # Extract trading signal and related parameters from the indicators row
            trading_signal = row.get("trading_signal", "HOLD")
            risk_level = row.get("risk_level", "LOW")
            atr_14 = row.get("atr_14", np.nan)
            stop_loss_price = row.get("stop_loss_price", np.nan)
            take_profit_price = row.get("take_profit_price", np.nan)

            # Calculate the amount of risk (in dollars) based on the current risk level and account balance
            risk_percentage = risk_map.get(risk_level, 0.01)
            risk_amount = account_balance * risk_percentage

            # Compute risk per unit (i.e., risk per share): if stop loss price is available, use its difference with current price,
            # otherwise default to 2% of the current price
            if not pd.isna(stop_loss_price):
                risk_per_unit = abs(current_price - stop_loss_price)
            else:
                risk_per_unit = current_price * 0.02

            # Determine position size based on the trading signal
            # If the signal is HOLD, no position is taken; otherwise, calculate the number of shares to buy
            if trading_signal == "HOLD":
                position_units = 0
                position_size = 0
            else:
                if risk_per_unit > 0:
                    position_units = risk_amount // risk_per_unit
                else:
                    position_units = risk_amount // current_price
                position_size = position_units * current_price

            # Initialize default action details: action detail, actual trade price, and profit (only meaningful for SELL actions)
            action_detail = "HOLD - no action"
            actual_price = current_price  # Default execution price is set to the closing price
            profit = None  # Profit/loss is calculated and recorded only when a SELL action is executed


                        # Simulate trade execution: Determine if the preset stop loss or take profit prices are hit based on the day's price range
            if trading_signal == "BUY":
                # For a BUY signal: normally, the stop loss price is below the current price and the take profit price is above it
                if not pd.isna(stop_loss_price) and daily_low <= stop_loss_price:
                    actual_price = stop_loss_price
                elif not pd.isna(take_profit_price) and daily_high >= take_profit_price:
                    actual_price = take_profit_price
                else:
                    actual_price = current_price

                # Recalculate the position size based on the actual execution price
                position_size = position_units * actual_price

                if account_balance >= position_size:
                    account_balance -= position_size
                    # Update the portfolio: add the newly bought units and update the weighted average cost
                    old_units = portfolio.get(tic, 0)
                    old_avg_cost = portfolio.get("avg_cost", 0)
                    new_units = position_units
                    if old_units == 0:
                        portfolio["avg_cost"] = actual_price
                    else:
                        portfolio["avg_cost"] = (old_units * old_avg_cost + new_units * actual_price) / (old_units + new_units)
                    portfolio[tic] = old_units + new_units
                    action_detail = f"BUY executed: Bought {new_units:.2f} units at {actual_price:.2f}, cost {position_size:.2f}"
                else:
                    position_units = 0
                    position_size = 0
                    action_detail = "BUY signal but insufficient funds"

            elif trading_signal == "SELL":
                # For a SELL signal: Execute closing of the position
                held_units = portfolio.get(tic, 0)
                if held_units <= 0:
                    position_units = 0
                    position_size = 0
                    action_detail = "SELL signal but no holdings"
                else:
                    if not pd.isna(take_profit_price) and daily_high >= take_profit_price:
                        actual_price = take_profit_price
                    elif not pd.isna(stop_loss_price) and daily_low <= stop_loss_price:
                        actual_price = stop_loss_price
                    else:
                        actual_price = current_price
                    position_units = held_units
                    position_size = held_units * actual_price
                    account_balance += position_size
                    # Calculate profit/loss: sale proceeds minus (held units multiplied by average cost)
                    avg_cost = portfolio.get("avg_cost", actual_price)
                    profit = position_size - (held_units * avg_cost)
                    action_detail = f"SELL executed: Sold {held_units:.2f} units at {actual_price:.2f}, proceeds {position_size:.2f}, profit {profit:.2f}"
                    # After closing the position, clear the holding information
                    portfolio[tic] = 0
                    portfolio["avg_cost"] = 0
            else:
                action_detail = "HOLD - no action"

            # Construct the record dictionary for this trade
            record = {
                "date": date,
                "trading_signal": trading_signal,
                "position_units": position_units,
                "position_size": position_size,
                "account_balance": account_balance,
                "action_detail": action_detail,
                "actual_price": actual_price,
                "profit": profit
            }
            records.append(record)

        # Convert the list of records into a DataFrame and set 'date' as the index (optional)
        positions_df = pd.DataFrame(records).set_index("date")
        # Optionally merge the trade records with the indicators DataFrame to view trading details for each date
        indicators = pd.merge(indicators, positions_df, left_index=True, right_index=True, how="left")
        # Update the state with the new indicators, account balance, and portfolio information
        state["indicators"] = indicators
        state["account_balance"] = account_balance
        state["portfolio"] = portfolio

        # Save all trade records into the state for later analysis
        state["trade_history"] = records

        # Output updated information for review
        print("Updated indicators with dynamic account and position info:")
        print(indicators.tail())
        print("Final account balance: ", account_balance)
        print("Final portfolio holdings: ", portfolio)
        print("Trade history (last 5 records):")
        for rec in records[-5:]:
            print(rec)



#%%
class BacktestAgent:
    """
    Backtest Agent:
    Reads state["trade_history"] (a list of trade records) and uses state["daily_data"] to calculate the final portfolio value
    (cash balance + market value of holdings). It then computes key performance metrics including total return,
    maximum drawdown, Sharpe ratio, and win rate.
    """
    def run(self, state):
        # Retrieve ticker symbol from state, defaulting to "NVDA" if not provided.
        tic = state.get("tic", "NVDA") 
        print("Running backtest performance analysis...")

        # Initial balance (should be set in state)
        initial_balance = state.get("initial_balance", 100000)
        # Current cash balance updated by PortfolioManagementAgent
        cash_balance = state.get("account_balance", initial_balance)
        # Retrieve portfolio holdings; assume holdings for ticker 'tic'
        portfolio = state.get("portfolio", {})
        held_units = portfolio.get(tic, 0)

        # Get daily price data; daily_data must include a datetime index and "Close", "High", "Low" columns
        daily_data = state.get("daily_data", pd.DataFrame())
        if daily_data.empty:
            print("Daily data is empty, cannot compute final portfolio value.")
            return

        # Ensure daily_data is sorted by date
        daily_data = daily_data.sort_index()
        # Calculate the market value of the holdings using the closing price on the last trading day
        latest_date = daily_data.index[-1]
        latest_price = daily_data.loc[latest_date, "Close"]
        portfolio_value = held_units * latest_price

        # Final portfolio value: cash balance + market value of holdings
        final_portfolio_value = cash_balance + portfolio_value

        # Read trade history; state["trade_history"] is a list where each element is a dictionary representing a trade
        trade_history = state.get("trade_history", [])
        if trade_history:
            # Convert the trade history list into a DataFrame
            trades_df = pd.DataFrame(trade_history)
            # Sort the trade records by trade date
            trades_df.sort_values("date", inplace=True)
            # Rename field if inconsistent (e.g., "trading_signal_y" to "trading_signal")
            if "trading_signal" not in trades_df.columns and "trading_signal_y" in trades_df.columns:
                trades_df.rename(columns={"trading_signal_y": "trading_signal"}, inplace=True)
            # Build the equity curve: use the account cash balance after each trade as the data points
            equity_curve = trades_df["account_balance"].copy()
            # Update the last node in the equity curve to be the final portfolio value
            equity_curve.iloc[-1] = final_portfolio_value
        else:
            # If there are no trade records, the equity curve contains only the final portfolio value
            trades_df = pd.DataFrame()  # Ensure variable is defined
            equity_curve = pd.Series([final_portfolio_value])

        # Compute periodic returns based on the equity curve (using trade records as nodes)
        daily_returns = equity_curve.pct_change().dropna()
        # Compute Sharpe ratio: assuming a risk-free rate of 0 and annualizing with a factor of 252 trading days
        if daily_returns.std() != 0:
            sharpe_ratio = (daily_returns.mean() / daily_returns.std()) * np.sqrt(252)
        else:
            sharpe_ratio = np.nan

        # Compute maximum drawdown
        running_max = equity_curve.cummax()
        drawdown = (equity_curve - running_max) / running_max
        max_drawdown = drawdown.min()  # Negative value indicates the maximum drawdown

        # Calculate win rate: filter SELL or STOP LOSS trades and compute the proportion with profit > 0
        if not trades_df.empty:
            if "trading_signal" not in trades_df.columns and "trading_signal_y" in trades_df.columns:
                trades_df.rename(columns={"trading_signal_y": "trading_signal"}, inplace=True)
            sell_trades = trades_df[trades_df["trading_signal"].isin(["SELL", "STOP LOSS"])]
            if not sell_trades.empty and "profit" in sell_trades.columns:
                win_rate = (sell_trades["profit"].dropna() > 0).mean()  # Proportion of profitable trades
            else:
                win_rate = np.nan
        else:
            win_rate = np.nan

        # Total return: based on the final portfolio value relative to the initial balance
        total_return = (final_portfolio_value - initial_balance) / initial_balance

        # Print backtest performance summary
        print("Backtest Performance Summary:")
        print("Initial Balance: {:.2f}".format(initial_balance))
        print("Final Cash Balance: {:.2f}".format(cash_balance))
        print("Portfolio Value: {:.2f}".format(portfolio_value))
        print("Final Portfolio Value (Cash + Holdings): {:.2f}".format(final_portfolio_value))
        print("Total Return: {:.2%}".format(total_return))
        print("Max Drawdown: {:.2%}".format(max_drawdown))
        print("Sharpe Ratio: {:.2f}".format(sharpe_ratio))
        if not np.isnan(win_rate):
            print("Win Rate: {:.2%}".format(win_rate))
        else:
            print("Win Rate: N/A (no SELL trades recorded)")

        # Create a dictionary of performance metrics
        performance = {
            "initial_balance": initial_balance,
            "final_cash_balance": cash_balance,
            "portfolio_value": portfolio_value,
            "final_portfolio_value": final_portfolio_value,
            "total_return": total_return,
            "max_drawdown": max_drawdown,
            "sharpe_ratio": sharpe_ratio,
            "win_rate": win_rate,
        }
        state["performance"] = performance
        return performance
#%%
def construct_daily_equity(state):
    tic = state.get("tic", "NVDA") 
    # Retrieve and sort daily data by date
    daily_data = state.get("daily_data", pd.DataFrame()).sort_index()
    # Get trade history (a list of trade records)
    trade_history = state.get("trade_history", [])
    
    # Initial state: starting with the initial balance and zero holdings
    current_cash = state.get("initial_balance", 100000)
    current_units = 0
    
    dates = daily_data.index
    equity_values = []
    
    # Convert trade history to a DataFrame (ensure that the trade dates are in pd.Timestamp format)
    if trade_history:
        trades_df = pd.DataFrame(trade_history)
        trades_df["date"] = pd.to_datetime(trades_df["date"])
        trades_df.sort_values("date", inplace=True)
    else:
        trades_df = pd.DataFrame()
    
    # Iterate over each date in daily_data
    for date in dates:
        # If there are trades for the current date, update cash and positions accordingly
        if not trades_df.empty:
            trades_today = trades_df[trades_df["date"] == date]
            if not trades_today.empty:
                # Use the last trade of the day to update the status
                last_trade = trades_today.iloc[-1]
                current_cash = last_trade["account_balance"]
                # If the record contains position units, update the current holding
                if "position_units" in last_trade:
                    # For BUY signals, add the new units; for SELL signals, position is typically closed (set to 0)
                    current_units = last_trade["position_units"] if last_trade["trading_signal"].upper() in ["BUY"] else 0
                # If there's a separate field for holdings, prefer the information from state["portfolio"]
                current_units = state.get("portfolio", {}).get(tic, current_units)
        # Calculate the day's equity: cash balance + (current holding * closing price)
        close_price = daily_data.loc[date, "Close"]
        equity = current_cash + current_units * close_price
        equity_values.append(equity)
    
    # Create a Series for the equity curve using dates as the index
    equity_curve = pd.Series(equity_values, index=dates)
    return equity_curve

class VisualizationAgent:
    """
    Visualization Agent:
    Provides multiple charts to display the performance of the trading strategy.
    """
    tic = state.get("tic", "NVDA") 
    def plot_equity_curve(self, equity_curve):
        # Plot the daily equity curve (portfolio value over time)
        plt.figure(figsize=(12, 6))
        plt.plot(equity_curve.index, equity_curve.values, label="Equity Curve", color="blue")
        plt.title("Daily Equity Curve")
        plt.xlabel("Date")
        plt.ylabel("Portfolio Value")
        plt.legend()
        plt.grid(True)
        plt.show()

    def plot_drawdown(self, equity_curve):
        # Calculate the running maximum of the equity curve
        running_max = equity_curve.cummax()
        # Compute drawdown as the percentage decline from the running maximum
        drawdown = (equity_curve - running_max) / running_max
        # Plot the drawdown curve
        plt.figure(figsize=(12, 4))
        plt.plot(equity_curve.index, drawdown, color="red", label="Drawdown")
        plt.title("Equity Drawdown")
        plt.xlabel("Date")
        plt.ylabel("Drawdown (%)")
        plt.legend()
        plt.grid(True)
        plt.show()

    def plot_returns_histogram(self, equity_curve):
        # Calculate daily returns from the equity curve
        returns = equity_curve.pct_change().dropna()
        # Plot a histogram of daily returns
        plt.figure(figsize=(8, 4))
        plt.hist(returns, bins=30, edgecolor="black", color="gray")
        plt.title("Daily Returns Histogram")
        plt.xlabel("Daily Return")
        plt.ylabel("Frequency")
        plt.grid(True)
        plt.show()

    def plot_trades_on_equity(self, equity_curve, state):
        # Retrieve trade history from the state
        trade_history = state.get("trade_history", [])
        if trade_history:
            trades_df = pd.DataFrame(trade_history)
            trades_df["date"] = pd.to_datetime(trades_df["date"])
            trades_df.sort_values("date", inplace=True)
        else:
            trades_df = pd.DataFrame()
        
        # Plot the equity curve
        plt.figure(figsize=(12, 6))
        plt.plot(equity_curve.index, equity_curve.values, label="Equity Curve", color="blue")
        
        if not trades_df.empty:
            # Convert trading signals to uppercase for consistency
            trades_df["trading_signal"] = trades_df["trading_signal"].str.upper()
            # Separate BUY and SELL (or STOP LOSS) trades
            buys = trades_df[trades_df["trading_signal"] == "BUY"]
            sells = trades_df[trades_df["trading_signal"].isin(["SELL", "STOP LOSS"])]
            
            # Plot BUY and SELL signals on the equity curve using the account balance at the time of the trade
            plt.scatter(buys["date"], buys["account_balance"], marker="^", color="green", s=100, label="BUY")
            plt.scatter(sells["date"], sells["account_balance"], marker="v", color="red", s=100, label="SELL")
        
        plt.title("Equity Curve with Trade Signals")
        plt.xlabel("Date")
        plt.ylabel("Portfolio Value")
        plt.legend()
        plt.grid(True)
        plt.show()
    
    def plot_stock_with_signals(self, state):
        # Retrieve and sort daily price data from state
        daily_data = state.get("daily_data", pd.DataFrame()).sort_index()
        # Retrieve trade history from state
        trade_history = state.get("trade_history", [])
    
        # If daily data is empty, print a message and exit the function
        if daily_data.empty:
            print("No daily_data available.")
            return
    
        # Convert trade history into a DataFrame
        if trade_history:
            trades_df = pd.DataFrame(trade_history)
            trades_df["date"] = pd.to_datetime(trades_df["date"])
            trades_df.sort_values("date", inplace=True)
        else:
            trades_df = pd.DataFrame()
    
        plt.figure(figsize=(12, 6))
        # Plot the stock price curve using the closing prices
        plt.plot(daily_data.index, daily_data["Close"], label="Close Price", color="blue")
    
        if not trades_df.empty:
            # Convert trading signals to uppercase for filtering
            trades_df["trading_signal"] = trades_df["trading_signal"].str.upper()
            # Filter for BUY and SELL/STOP LOSS records
            buys = trades_df[trades_df["trading_signal"] == "BUY"]
            sells = trades_df[trades_df["trading_signal"].isin(["SELL", "STOP LOSS"])]
            # Mark the trade points on the stock price chart
            # Note: It is assumed that the dates in trades_df match the dates in daily_data
            plt.scatter(buys["date"], daily_data.loc[buys["date"], "Close"], 
                        marker="^", color="green", s=100, label="BUY")
            plt.scatter(sells["date"], daily_data.loc[sells["date"], "Close"], 
                        marker="v", color="red", s=100, label="SELL")
    
        plt.title("Stock Price with Buy/Sell Signals")
        plt.xlabel("Date")
        plt.ylabel("Price")
        plt.legend()
        plt.grid(True)
        plt.show()

    def run(self, state):
        # Construct the daily equity curve based on daily data and trade history
        equity_curve = construct_daily_equity(state)
        
        # Plot the daily equity curve
        self.plot_equity_curve(equity_curve)
        # Plot the equity drawdown
        self.plot_drawdown(equity_curve)
        # Plot the histogram of daily returns
        self.plot_returns_histogram(equity_curve)
        # Plot the equity curve with trade signals marked
        self.plot_trades_on_equity(equity_curve, state)
        # Plot the stock price along with buy/sell signals
        self.plot_stock_with_signals(state)
#%% combine DataCollectionAgent & DataAnalysisAgent
def run_trading_system():
    agents = [DataCollectionAgent()]
    for agent in agents:
        agent.run(state)

if __name__ == "__main__":
    run_trading_system()
#%% combine DataCollectionAgent & DataAnalysisAgent
def run_trading_system():
    agents = [DataAnalysisAgent(),StrategyDevelopmentAgent(),PortfolioManagementAgent(),BacktestAgent(),VisualizationAgent()]
    for agent in agents:
        agent.run(state)

if __name__ == "__main__":
    run_trading_system()
#%% combine DataCollectionAgent & DataAnalysisAgent
def run_trading_system():
    agents = [DataCollectionAgent(), DataAnalysisAgent(),StrategyDevelopmentAgent(),PortfolioManagementAgent(),BacktestAgent(),VisualizationAgent()]
    for agent in agents:
        agent.run(state)

if __name__ == "__main__":
    run_trading_system()
#%%
# Define risk mapping for risk levels
risk_map = {"LOW": 0.01, "MEDIUM": 0.02, "HIGH": 0.03}

# Retrieve the indicators DataFrame from state (it contains merged trade logs)
indicators = state.get("indicators", pd.DataFrame()).copy()

# Reset index to make sure 'date' is a column
indicators = indicators.reset_index()

# Ensure trading signal column is named "trading_signal_y"
if "trading_signal_y" not in indicators.columns and "trading_signal" in indicators.columns:
    indicators["trading_signal_y"] = indicators["trading_signal"]

# Filter out rows with HOLD signal
filtered_trades = indicators[indicators["trading_signal_y"].str.upper() != "HOLD"].copy()

# Map risk_level to risk_control based on the risk_map
filtered_trades["risk_control"] = filtered_trades["risk_level"].map(risk_map)

# Select the desired columns
export_columns = [
    "date",                # Trade time
    "trading_signal_y",    # Trading signal
    "risk_level",          # Trade risk level
    "risk_control",        # Account risk-based position control value
    "position_size",       # Funds invested in the trade
    "action_detail",       # Specific trade operation details
    "profit"               # Profit from the trade
]

export_df = filtered_trades[[col for col in export_columns if col in filtered_trades.columns]]

# Export to Excel file
export_df.to_excel("trade_logs_risk.xlsx", index=False)

# Show performance
performance = state.get("performance")
pp = pprint.PrettyPrinter(indent=2)
pp.pprint(performance)

