# -*- coding: utf-8 -*-
"""
Created on Tue May  6 12:50:46 2025

@author: liang
"""
import os
import pandas as pd
import numpy as np

# --- PARAMETERS ---
INIT_CAPITAL = 1_000_000   # starting capital
TRADING_DAYS = 252         # trading days per year

# 1. find all *_report.xlsx files
files = [f for f in os.listdir('.') if f.endswith('_report.xlsx')]

# 2. load each file, map string signals to numeric, compute daily P&L
pl_list = []
for f in files:
    df = pd.read_excel(f, parse_dates=['Date']).sort_values('Date')
    # map BUY→1, SELL→-1, NEUTRAL→0
    df['Units'] = df['Signal'].map({'BUY': 1, 'SELL': -1, 'NEUTRAL': 0})
    # compute price change
    df['PriceChange'] = df['Price'].diff().fillna(0)
    # daily P&L = units × price change
    df['Change'] = df['Units'] * df['PriceChange']
    pl_list.append(df[['Date','Change']])

# 3. aggregate across symbols
daily_pl = pd.concat(pl_list).groupby('Date')['Change'].sum().sort_index()

# 4. build equity curve and daily returns
equity  = INIT_CAPITAL + daily_pl.cumsum()
returns = daily_pl / equity.shift(1)
returns = returns.fillna(0)

# 5. compute performance metrics
days = len(returns)
# CAGR
cagr = (equity.iloc[-1] / INIT_CAPITAL)**(TRADING_DAYS/days) - 1
# annualized vol
vol = returns.std(ddof=1) * np.sqrt(TRADING_DAYS)
# Sharpe Ratio
sharpe = returns.mean() / returns.std(ddof=1) * np.sqrt(TRADING_DAYS)
# max drawdown
running_max = equity.cummax()
max_dd = ((equity - running_max) / running_max).min()
# Sortino Ratio
downside = returns.copy()
downside[downside > 0] = 0
down_std = downside.std(ddof=1) * np.sqrt(TRADING_DAYS)
sortino = returns.mean()*np.sqrt(TRADING_DAYS) / down_std if down_std != 0 else np.nan
# Win rate
wins = (returns > 0).sum()
losses = (returns < 0).sum()
win_rate = wins / (wins + losses) if (wins + losses)>0 else np.nan
# Profit Factor
total_win  = daily_pl[daily_pl>0].sum()
total_loss = -daily_pl[daily_pl<0].sum()
profit_factor = total_win / total_loss if total_loss > 0 else np.nan

# 6. print results
print(f"CAGR:               {cagr:.2%}")
print(f"Volatility:         {vol:.2%}")
print(f"Sharpe Ratio:       {sharpe:.2f}")
print(f"Max Drawdown:       {max_dd:.2%}")
print(f"Sortino Ratio:      {sortino:.2f}")
print(f"Win Rate:           {win_rate:.2%}")
print(f"Profit Factor:      {profit_factor:.2f}")
#%%
import os
import pandas as pd
import numpy as np

# --- PARAMETERS ---
INIT_CAPITAL = 1_000_000   # starting capital
TRADING_DAYS = 252         # trading days per year

# 1. find all *_report.xlsx files
files = [f for f in os.listdir('.') if f.endswith('_report_1.xlsx')]

# 2. load each file, map string signals to numeric, compute daily P&L
pl_list = []
for f in files:
    df = pd.read_excel(f, parse_dates=['Date']).sort_values('Date')
    # map BUY→1, SELL→-1, NEUTRAL→0
    df['Units'] = df['Signal'].map({'BUY': 1, 'SELL': -1, 'NEUTRAL': 0})
    # compute price change
    df['PriceChange'] = df['Price'].diff().fillna(0)
    # daily P&L = units × price change
    df['Change'] = df['Units'] * df['PriceChange']
    pl_list.append(df[['Date','Change']])

# 3. aggregate across symbols
daily_pl = pd.concat(pl_list).groupby('Date')['Change'].sum().sort_index()

# 4. build equity curve and daily returns
equity  = INIT_CAPITAL + daily_pl.cumsum()
returns = daily_pl / equity.shift(1)
returns = returns.fillna(0)

# 5. compute performance metrics
days = len(returns)
# CAGR
cagr = (equity.iloc[-1] / INIT_CAPITAL)**(TRADING_DAYS/days) - 1
# annualized vol
vol = returns.std(ddof=1) * np.sqrt(TRADING_DAYS)
# Sharpe Ratio
sharpe = returns.mean() / returns.std(ddof=1) * np.sqrt(TRADING_DAYS)
# max drawdown
running_max = equity.cummax()
max_dd = ((equity - running_max) / running_max).min()
# Sortino Ratio
downside = returns.copy()
downside[downside > 0] = 0
down_std = downside.std(ddof=1) * np.sqrt(TRADING_DAYS)
sortino = returns.mean()*np.sqrt(TRADING_DAYS) / down_std if down_std != 0 else np.nan
# Win rate
wins = (returns > 0).sum()
losses = (returns < 0).sum()
win_rate = wins / (wins + losses) if (wins + losses)>0 else np.nan
# Profit Factor
total_win  = daily_pl[daily_pl>0].sum()
total_loss = -daily_pl[daily_pl<0].sum()
profit_factor = total_win / total_loss if total_loss > 0 else np.nan

# 6. print results
print(f"CAGR:               {cagr:.2%}")
print(f"Volatility:         {vol:.2%}")
print(f"Sharpe Ratio:       {sharpe:.2f}")
print(f"Max Drawdown:       {max_dd:.2%}")
print(f"Sortino Ratio:      {sortino:.2f}")
print(f"Win Rate:           {win_rate:.2%}")
print(f"Profit Factor:      {profit_factor:.2f}")
