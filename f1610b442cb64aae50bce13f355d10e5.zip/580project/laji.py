# -*- coding: utf-8 -*-
"""
Created on Sun May  4 17:44:04 2025

@author: liang
"""

        # --------------------------------------------------------------------

        # Initialise columns
        indicators[[
            "trading_signal", "signal_confidence",
            "stop_loss_price", "take_profit_price", "risk_level"
        ]] = ["HOLD", 50, np.nan, np.nan, "LOW"]
        indicators["signal_reasons"] = None

        all_signal_reasons = []

        for i in range(1, len(indicators)):
            # --- Skip if critical indicators are nan -----------------------
            required_cols = ["sma_50", "sma_200", "rsi_14", "macd_line", "macd_signal"]
            if indicators.iloc[i][required_cols].isna().any():
                continue

            current_date = indicators.index[i]
            if current_date not in daily_data.index:
                continue

            current_price = daily_data.loc[current_date, "Close"]
            sma_50 = indicators.loc[current_date, "sma_50"]
            sma_200 = indicators.loc[current_date, "sma_200"]
            rsi_14 = indicators.loc[current_date, "rsi_14"]
            macd_line = indicators.loc[current_date, "macd_line"]
            macd_signal = indicators.loc[current_date, "macd_signal"]
            bollinger_upper = indicators.loc[current_date, "bollinger_upper"]
            bollinger_lower = indicators.loc[current_date, "bollinger_lower"]
            atr_14 = indicators.loc[current_date, "atr_14"]

            signal_reasons = []

            # --- Trend determination (unchanged) ---------------------------
            trend = "uptrend" if current_price > sma_200 else "downtrend"
            signal_reasons.append(
                "Price above 200‑day SMA, uptrend confirmed" if trend == "uptrend"
                else "Price below 200‑day SMA, downtrend confirmed"
            )

            buy_cond = 0.0
            sell_cond = 0.0

            # Technical BUY conditions
            if trend == "uptrend" and 0.99 * sma_50 <= current_price <= 1.01 * sma_50:
                buy_cond += 1
                signal_reasons.append("Price near 50‑day SMA support")
            if rsi_14 < 40 and rsi_14 > indicators["rsi_14"].iloc[i - 1]:
                buy_cond += 1
                signal_reasons.append("RSI < 40 and rising")
            if macd_line > macd_signal and indicators["macd_line"].iloc[i - 1] <= indicators["macd_signal"].iloc[i - 1]:
                buy_cond += 1
                signal_reasons.append("MACD golden cross")
            if current_price < bollinger_lower * 1.02:
                buy_cond += 1
                signal_reasons.append("Price near lower Bollinger")

            # Technical SELL conditions
            if trend == "downtrend" and current_price < sma_50:
                sell_cond += 1
                signal_reasons.append("Price breaks 50‑day SMA support")
            if rsi_14 > 70 and rsi_14 < indicators["rsi_14"].iloc[i - 1]:
                sell_cond += 1
                signal_reasons.append("RSI > 70 and falling")
            if macd_line < macd_signal and indicators["macd_line"].iloc[i - 1] >= indicators["macd_signal"].iloc[i - 1]:
                sell_cond += 1
                signal_reasons.append("MACD death cross")
            if current_price > bollinger_upper * 0.98:
                sell_cond += 1
                signal_reasons.append("Price near upper Bollinger")
