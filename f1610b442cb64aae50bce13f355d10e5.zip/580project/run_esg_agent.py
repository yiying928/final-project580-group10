import os
import sys

# Add the project root directory to Python path
src_dir = r"C:\Users\liang\OneDrive\Desktop\580project"
sys.path.insert(0, src_dir)

# Now we can import from the agents directory using absolute imports
from agents.esg_news import esg_news_agent
from graph.state import AgentState
from data.models import Portfolio
from tools.esg_news_api import get_esg_news, analyze_esg_sentiment, get_api_key

# Check if API key is set
def check_api_key():
    """Check if NewsAPI key is set and provide instructions if not"""
    api_key = get_api_key()
    if not api_key:
        print("\nERROR: NewsAPI key is not set. Please set your API key using one of these methods:")
        print("1. Set the NEWS_API_KEY environment variable:")
        print("   - For macOS/Linux: export NEWS_API_KEY=your_api_key_here")
        print("   - For Windows: set NEWS_API_KEY=your_api_key_here")
        print("2. Or edit the esg_news_api.py file to set the default API key")
        print("\nYou can get a free API key at https://newsapi.org/register")
        return False
    return True

# 在这里修改您想要分析的股票代码和日期范围
# 您可以直接修改以下变量的值，而不需要通过命令行参数
DEFAULT_TICKER = "NVDA"  # 股票代码，例如：AAPL（苹果）、MSFT（微软）、TSLA（特斯拉）等
DEFAULT_START_DATE = "2025-04-05"  # 开始日期，格式：YYYY-MM-DD
DEFAULT_END_DATE = "2025-0-30"  # 结束日期，格式：YYYY-MM-DD

# Example usage
def run_esg_agent(use_direct_api=False, export_csv=True, output_dir=None, start_date=DEFAULT_START_DATE, end_date=DEFAULT_END_DATE, ticker=DEFAULT_TICKER):
    print("Running ESG News Agent...")
    
    # 允许用户自定义时间范围，如果未提供则使用默认值
    from datetime import datetime, timedelta
    
    # 如果未提供日期，则使用默认值（使用上面设置的DEFAULT_START_DATE和DEFAULT_END_DATE）
    # 注意：这里的None或空字符串检查是为了处理命令行参数未提供的情况
    # 在main函数中已经确保了传入的start_date和end_date要么是用户指定的值，要么是DEFAULT值
    # 这里只需要处理空字符串的情况
    if end_date == "":
        end_date = DEFAULT_END_DATE
    if start_date == "":
        start_date = DEFAULT_START_DATE
    
    print(f"使用时间范围: {start_date} 到 {end_date}")
    # Note: Free NewsAPI plan has very limited historical access
    
    state = AgentState(
        messages=[],
        data={
            "tickers": [ticker],
            "start_date": start_date,  # 使用用户提供的开始日期
            "end_date": end_date,      # 使用用户提供的结束日期
            "portfolio": Portfolio(positions={}, total_cash=1000000.0),
            "analyst_signals": {},
        },
        metadata={
            "show_reasoning": True,
            "model_name": "gpt-4",
            "model_provider": "openai",
        },
    )
    
    # First check if API key is set
    if not check_api_key():
        print("\nCannot proceed without a valid API key.")
        return
        
    # Create output directory for CSV files if specified
    if export_csv and output_dir:
        os.makedirs(output_dir, exist_ok=True)
        csv_news_path = os.path.join(output_dir, f"{ticker}_esg_news.csv")
        csv_sentiment_path = os.path.join(output_dir, f"{ticker}_esg_sentiment.csv")
    else:
        csv_news_path = f"{ticker}_esg_news.csv"
        csv_sentiment_path = f"{ticker}_esg_sentiment.csv"
    
    try:
        if use_direct_api:
            # Use the direct API approach instead of the agent
            print(f"Fetching ESG news for {ticker} from {start_date} to {end_date}...")
            try:
                news_items = get_esg_news(
                    ticker=ticker,
                    start_date=start_date,
                    end_date=end_date,
                    export_csv=export_csv,
                    csv_filename=csv_news_path
                )
                
                if news_items:
                    print(f"Found {len(news_items)} ESG-related news items")
                    # 为每日ESG得分创建CSV路径
                    csv_daily_scores_path = os.path.join(output_dir, f"{ticker}_daily_esg_scores.csv") if output_dir else f"{ticker}_daily_esg_scores.csv"
                    
                    sentiment_results = analyze_esg_sentiment(
                        news_items=news_items,
                        export_csv=export_csv,
                        csv_filename=csv_sentiment_path,
                        daily_scores_csv=csv_daily_scores_path
                    )
                    print(f"\nESG情感分析结果:")
                    print(f"总体得分: {sentiment_results['score']:.2f}/10")
                    print(f"详情: {sentiment_results['details']}")
                    
                    # 显示每日ESG得分信息
                    if 'daily_scores' in sentiment_results and sentiment_results['daily_scores']:
                        print(f"\n每日ESG得分 (用于α信号):")
                        print("-" * 50)
                        print(f"{'日期':<12}{'ESG得分':<10}")
                        print("-" * 50)
                        
                        # 按日期排序显示每日得分
                        for date in sorted(sentiment_results['daily_scores'].keys()):
                            score = sentiment_results['daily_scores'][date]
                            print(f"{date:<12}{score:.2f}")
                        
                        print(f"\n每日ESG得分已导出到: {csv_daily_scores_path}")
                    else:
                        print("\n没有可用的每日ESG得分数据")
                else:
                    print("No ESG news found for the specified time range.")
                    print("Try expanding the date range or using a different ticker.")
            except Exception as api_error:
                print(f"Error fetching or processing news: {api_error}")
                print("\nPossible solutions:")
                print("1. Check your internet connection")
                print("2. Verify the API key is correct")
                print("3. The free NewsAPI plan has very limited historical access (usually only the last month)")
                print("4. Try using a different ticker with more news coverage")
        else:
            # Run the full ESG news agent
            print("Running ESG news analysis through agent...")
            result = esg_news_agent(state)
            
            # Access results
            if "analyst_signals" in result["data"] and "esg_news_agent" in result["data"]["analyst_signals"]:
                esg_analysis = result["data"]["analyst_signals"]["esg_news_agent"][ticker]
                print(f"\nESG Analysis Results:")
                print(f"Signal: {esg_analysis['signal']}")
                print(f"Confidence: {esg_analysis['confidence']}%")
                print(f"Reasoning: {esg_analysis['reasoning']}")
            else:
                print("\nESG analysis completed but no signals were generated.")
                print("This may be due to missing API credentials or insufficient data.")
    
    except Exception as e:
        print(f"Error running ESG News Agent: {str(e)}")
        print("\nNote: This may be due to missing API credentials or dependencies.")
        print("Try running the mock demo instead: python src/demo_esg_nvidia_mock.py")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run ESG News Analysis for NVIDIA")
    parser.add_argument("--use-agent", action="store_true", help="Use the full agent instead of direct API")
    parser.add_argument("--no-csv", action="store_true", help="Disable CSV export")
    parser.add_argument("--output-dir", type=str, help="Directory to save CSV files")
    parser.add_argument("--ticker", type=str, default="NVDA", help="Stock ticker symbol (default: NVDA)")
    parser.add_argument("--start-date", type=str, help="Start date in YYYY-MM-DD format")
    parser.add_argument("--end-date", type=str, help="End date in YYYY-MM-DD format")
    
    args = parser.parse_args()
    
    # 只有当命令行参数明确提供时才使用它们，否则使用默认值
    start_date = args.start_date if args.start_date is not None else DEFAULT_START_DATE
    end_date = args.end_date if args.end_date is not None else DEFAULT_END_DATE
    
    # Run with parsed arguments
    run_esg_agent(
        use_direct_api=not args.use_agent,  # Default is direct API unless --use-agent is specified
        export_csv=not args.no_csv,         # Default is to export CSV unless --no-csv is specified
        output_dir=args.output_dir,         # Optional output directory
        start_date=start_date,              # 使用处理后的开始日期
        end_date=end_date,                  # 使用处理后的结束日期
        ticker=args.ticker                  # Optional ticker symbol
    )