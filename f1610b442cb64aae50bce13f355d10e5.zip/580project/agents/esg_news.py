from langchain_core.messages import HumanMessage
from graph.state import AgentState, show_agent_reasoning
from utils.progress import progress
import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Tuple, Optional

from tools.api import get_company_news


# ESG Category Keywords for classification
ESG_KEYWORDS = {
    "Environmental": [
        "climate", "carbon", "emission", "renewable", "sustainable", "green", 
        "pollution", "waste", "recycling", "energy efficiency", "water", 
        "biodiversity", "conservation", "environmental"
    ],
    "Social": [
        "diversity", "inclusion", "equity", "human rights", "labor", "employee", 
        "community", "health", "safety", "privacy", "data protection", "customer", 
        "social impact", "wellbeing", "education", "training"
    ],
    "Governance": [
        "board", "director", "executive", "compensation", "ethics", "compliance", 
        "transparency", "accountability", "shareholder", "voting", "audit", 
        "risk management", "corruption", "bribery", "governance", "regulation", 
        "policy", "disclosure", "SEC", "filing"
    ]
}


def classify_esg_category(title: str, excerpt: str) -> str:
    """
    Classify news into Environmental, Social, or Governance categories based on keyword matching.
    """
    text = (title + " " + excerpt).lower()
    
    category_scores = {}
    for category, keywords in ESG_KEYWORDS.items():
        category_scores[category] = sum(1 for keyword in keywords if keyword.lower() in text)
    
    # If no ESG keywords found, return "Unclassified"
    if sum(category_scores.values()) == 0:
        return "Unclassified"
    
    # Return the category with the highest score
    return max(category_scores.items(), key=lambda x: x[1])[0]


def calculate_relevance_score(title: str, excerpt: str, ticker: str) -> int:
    """
    Calculate relevance score (0-10) based on direct mentions and materiality to core operations.
    """
    text = (title + " " + excerpt).lower()
    ticker_lower = ticker.lower()
    
    # Base score starts at 0
    score = 0
    
    # Direct mentions of the company name or ticker
    if ticker_lower in text:
        score += 3
    
    # Check for materiality keywords
    materiality_keywords = [
        "significant", "material", "impact", "major", "substantial", 
        "core business", "operations", "strategy", "financial", "revenue", 
        "profit", "earnings", "guidance", "forecast", "outlook"
    ]
    
    materiality_score = sum(2 for keyword in materiality_keywords if keyword in text)
    score += min(materiality_score, 7)  # Cap at 7 to keep total under 10
    
    return min(score, 10)  # Ensure score doesn't exceed 10


def is_regulatory_filing(title: str, excerpt: str) -> bool:
    """
    Check if the news is related to a regulatory filing (e.g., SEC 8-K).
    """
    text = (title + " " + excerpt).lower()
    filing_keywords = ["8-k", "8k", "10-k", "10k", "10-q", "10q", "sec filing", "filed with sec", "regulatory filing"]
    
    return any(keyword in text for keyword in filing_keywords)


def calculate_z_score(series: pd.Series, window: int = 5) -> pd.Series:
    """
    Calculate rolling Z-score for a time series.
    """
    rolling_mean = series.rolling(window=window).mean()
    rolling_std = series.rolling(window=window).std()
    
    # Handle division by zero
    rolling_std = rolling_std.replace(0, np.nan)
    z_scores = (series - rolling_mean) / rolling_std
    
    return z_scores


def generate_alpha_signal(z_score: float) -> str:
    """
    Generate alpha signal based on Z-score threshold.
    """
    if z_score >= 1.5:
        return "Buy"
    elif z_score <= -1.5:
        return "Sell"
    else:
        return "Neutral"


def summarize_key_events(esg_news_df: pd.DataFrame, top_n: int = 3) -> List[str]:
    """
    Summarize top ESG drivers based on impact on composite score.
    """
    if esg_news_df.empty:
        return ["No significant ESG events found in the specified time range."]
    
    # Sort by weighted sentiment (impact)
    sorted_news = esg_news_df.sort_values(by="weighted_sentiment", ascending=False)
    
    summaries = []
    for category in ["Environmental", "Social", "Governance"]:
        category_news = sorted_news[sorted_news["esg_category"] == category]
        
        if not category_news.empty:
            top_news = category_news.iloc[0]
            date_str = top_news["date"].split("T")[0]
            impact = abs(top_news["weighted_sentiment"]) * 100  # Convert to percentage
            direction = "positive" if top_news["sentiment_score"] > 0 else "negative"
            
            summary = f"{category}: {top_news['headline']} drove {direction} score shift of {impact:.1f}% on {date_str}"
            summaries.append(summary)
    
    return summaries[:top_n]


def esg_news_agent(state: AgentState):
    """
    Analyzes ESG-related news for a ticker and generates composite scores and alpha signals.
    """
    data = state.get("data", {})
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    tickers = data.get("tickers")
    
    # Initialize ESG analysis for each ticker
    esg_analysis = {}
    
    for ticker in tickers:
        progress.update_status("esg_news_agent", ticker, "Fetching company news")
        
        # Get company news
        company_news = get_company_news(ticker, end_date, start_date=start_date, limit=100)
        
        if not company_news:
            progress.update_status("esg_news_agent", ticker, "No news data found")
            esg_analysis[ticker] = {
                "signal": "neutral",
                "confidence": 0,
                "reasoning": "No news data available for ESG analysis",
                "esg_data": None,
                "top_drivers": ["No ESG news data available"]
            }
            continue
        
        progress.update_status("esg_news_agent", ticker, "Processing ESG news")
        
        # Process news and extract ESG-related information
        esg_news_data = []
        for news in company_news:
            # Extract excerpt (use title if no content available)
            excerpt = news.title  # Assuming no content field in the API response
            
            # Classify ESG category
            esg_category = classify_esg_category(news.title, excerpt)
            
            # Skip non-ESG news
            if esg_category == "Unclassified":
                continue
            
            # Calculate relevance score
            relevance_score = calculate_relevance_score(news.title, excerpt, ticker)
            
            # Skip non-material ESG events (relevance score < 3)
            if relevance_score < 3:
                continue
            
            # Check if it's a regulatory filing
            is_filing = is_regulatory_filing(news.title, excerpt)
            
            # Convert API sentiment to numerical score (-1 to +1)
            sentiment_score = 0.0
            if news.sentiment == "positive":
                sentiment_score = 0.7
            elif news.sentiment == "negative":
                sentiment_score = -0.7
            elif news.sentiment == "neutral":
                sentiment_score = 0.0
            
            # Apply regulatory filing amplification if applicable
            if is_filing:
                sentiment_score *= 1.15  # Amplify by 15%
            
            # Calculate weighted sentiment (by relevance)
            weighted_sentiment = sentiment_score * (relevance_score / 10.0)
            
            # Add to ESG news data
            esg_news_data.append({
                "date": news.date,
                "source": news.source,
                "headline": news.title,
                "excerpt": excerpt,
                "sentiment_score": sentiment_score,
                "esg_category": esg_category,
                "relevance_score": relevance_score,
                "is_regulatory_filing": is_filing,
                "weighted_sentiment": weighted_sentiment
            })
        
        # If no ESG news found, return neutral signal
        if not esg_news_data:
            progress.update_status("esg_news_agent", ticker, "No ESG-related news found")
            esg_analysis[ticker] = {
                "signal": "neutral",
                "confidence": 0,
                "reasoning": "No ESG-related news found",
                "esg_data": None,
                "top_drivers": ["No ESG-related news found"]
            }
            continue
        
        progress.update_status("esg_news_agent", ticker, "Calculating composite scores")
        
        # Convert to DataFrame for time series analysis
        esg_df = pd.DataFrame(esg_news_data)
        esg_df["date"] = pd.to_datetime(esg_df["date"])
        esg_df.sort_values("date", inplace=True)
        
        # Group by date and calculate daily composite scores
        daily_scores = esg_df.groupby(esg_df["date"].dt.date).agg({
            "weighted_sentiment": "mean",  # Average weighted sentiment per day
            "headline": lambda x: ", ".join(x.iloc[:3]),  # Top 3 headlines
            "esg_category": lambda x: x.value_counts().index[0]  # Most common category
        }).reset_index()
        
        # Apply exponential smoothing to reduce noise
        alpha = 0.2  # Decay factor as specified
        daily_scores["smoothed_sentiment"] = daily_scores["weighted_sentiment"].ewm(alpha=alpha).mean()
        
        # Normalize to 0-100 scale
        min_val = daily_scores["smoothed_sentiment"].min()
        max_val = daily_scores["smoothed_sentiment"].max()
        
        if min_val == max_val:  # Handle case where all values are the same
            daily_scores["composite_esg_score"] = 50  # Default to neutral
        else:
            daily_scores["composite_esg_score"] = ((daily_scores["smoothed_sentiment"] - min_val) / 
                                               (max_val - min_val)) * 100
        
        # Calculate 5-day rolling Z-score
        daily_scores["z_score"] = calculate_z_score(daily_scores["composite_esg_score"])
        
        # Generate alpha signals
        daily_scores["alpha_signal"] = daily_scores["z_score"].apply(generate_alpha_signal)
        
        # Prepare final dataset
        esg_dataset = daily_scores[["date", "composite_esg_score", "z_score", "alpha_signal", "headline"]]
        esg_dataset.rename(columns={"headline": "key_event_summary"}, inplace=True)
        
        # Generate top ESG drivers summary
        top_drivers = summarize_key_events(esg_df)
        
        # Determine overall signal based on most recent alpha signal
        if not esg_dataset.empty:
            latest_signal = esg_dataset.iloc[-1]["alpha_signal"].lower()
            confidence = min(abs(esg_dataset.iloc[-1]["z_score"]) * 20, 100)  # Scale confidence based on Z-score
        else:
            latest_signal = "neutral"
            confidence = 0
        
        # Store results
        esg_analysis[ticker] = {
            "signal": latest_signal,
            "confidence": round(confidence),
            "reasoning": f"Based on ESG news analysis with {len(esg_news_data)} relevant articles",
            "esg_data": esg_dataset.to_dict(orient="records"),
            "top_drivers": top_drivers
        }
        
        progress.update_status("esg_news_agent", ticker, "Done")
    
    # Create the ESG news analysis message
    message = HumanMessage(
        content=json.dumps(esg_analysis),
        name="esg_news_agent",
    )
    
    # Print the reasoning if the flag is set
    if state["metadata"]["show_reasoning"]:
        show_agent_reasoning(esg_analysis, "ESG News Analysis Agent")
    
    # Add the signal to the analyst_signals list
    state["data"]["analyst_signals"]["esg_news_agent"] = esg_analysis
    
    return {
        "messages": [message],
        "data": data,
    }