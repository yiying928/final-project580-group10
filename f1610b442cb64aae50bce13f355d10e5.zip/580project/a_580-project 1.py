#%% Import 
import yfinance as yf
import pandas as pd
import numpy as np
from ta.trend import MACD
from ta.momentum import RSIIndicator
from ta.momentum import StochasticOscillator
from ta.volatility import BollingerBands
from ta.volatility import AverageTrueRange
from ta.volume import OnBalanceVolumeIndicator
import matplotlib.pyplot as plt
import pprint

#%% Initialize state
state = {
    # Ticker symbol for the asset to trade (default is "NVDA")
    "tic": "BAC",
    
    "src_dir" : r"C:\Users\caima\Desktop\580project",
    
    # DataFrame to store market data
    "market_data": pd.DataFrame(),  
    
    # DataFrame to store technical indicators
    "indicators": pd.DataFrame(),  
    
    # Trading signal (possible values: BUY, SELL, HOLD)
    "trading_signal": None,  
    
    # Confidence level of the trading signal
    "signal_confidence": None,  
        
    # Risk level associated with the trade
    "risk_level": None,  
    
    # Initial account balance
    "account_balance": 100000,  
    
    # Trade amount or position size in monetary terms
    "position_size": None,  
    
    # Number of shares or units to trade
    "position_units": None,  
    
    # Dictionary to store current portfolio holdings
    "portfolio": {},  
    
    # List to store trade history
    "trade_history": [],  
    
    # Current trade status (e.g., active, closed)
    "trade_status": None,  
    
    "esg_signals": {}, 
    
    #Backtest Performance Summary
    "performance": None
    
}
#%%DataCollectionAgent
class DataCollectionAgent:
    def run(self, state):
        # Get the ticker symbol from the state, defaulting to "NVDA" if not provided
        tic = state.get("tic", "NVDA")  
        
        # Define the benchmark symbol for S&P 500
        benchmark_symbol = "^GSPC"  # S&P 500
        
        # Fetch intraday market data for the past 7 days with 1-minute intervals for the specified ticker
        market_data = yf.Ticker(tic).history(period="7d", interval="1m")
        
        # Fetch daily market data for the past 3 years for the specified ticker
        daily_data = yf.Ticker(tic).history(period="3y", interval="1d")
        
        # Fetch daily benchmark data for the past 3 years for the S&P 500 index
        benchmark_data = yf.Ticker(benchmark_symbol).history(period="3y", interval="1d")
        
        # Store the fetched data in the state dictionary for further use
        state["market_data"] = market_data     
        state["daily_data"] = daily_data        
        state["benchmark_data"] = benchmark_data  
        
        # Print the first few rows of each dataset for verification purposes
        print(state["market_data"].head())
        print(state["daily_data"].head())
        print(state["benchmark_data"].head())
#%%
# Add the project root directory to Python path
src_dir=state.get("src_dir", r"C:\Users\liang\OneDrive\Desktop\580project")
sys.path.insert(0, src_dir)

# Now we can import from the agents directory using absolute imports
from agents.esg_news import esg_news_agent
from graph.state import AgentState
from data.models import Portfolio
from tools.esg_news_api import get_esg_news, analyze_esg_sentiment, get_api_key

# Check if API key is set
def check_api_key():
    """Check if NewsAPI key is set and provide instructions if not"""
    api_key = get_api_key()
    if not api_key:
        print("\nERROR: NewsAPI key is not set. Please set your API key using one of these methods:")
        print("1. Set the NEWS_API_KEY environment variable:")
        print("   - For macOS/Linux: export NEWS_API_KEY=your_api_key_here")
        print("   - For Windows: set NEWS_API_KEY=your_api_key_here")
        print("2. Or edit the esg_news_api.py file to set the default API key")
        print("\nYou can get a free API key at https://newsapi.org/register")
        return False
    return True

# 在这里修改您想要分析的股票代码和日期范围
# 您可以直接修改以下变量的值，而不需要通过命令行参数
DEFAULT_TICKER = state.get("tic", "NVDA")   # 股票代码，例如：AAPL（苹果）、MSFT（微软）、TSLA（特斯拉）等
DEFAULT_START_DATE = "2025-04-05"  # 开始日期，格式：YYYY-MM-DD
DEFAULT_END_DATE = "2025-05-02"  # 结束日期，格式：YYYY-MM-DD

# Example usage
def run_esg_agent(use_direct_api=False, export_csv=True, output_dir=None, start_date=DEFAULT_START_DATE, end_date=DEFAULT_END_DATE, ticker=DEFAULT_TICKER):
    print("Running ESG News Agent...")
    
    # 允许用户自定义时间范围，如果未提供则使用默认值
    from datetime import datetime, timedelta
    
    # 如果未提供日期，则使用默认值（使用上面设置的DEFAULT_START_DATE和DEFAULT_END_DATE）
    # 注意：这里的None或空字符串检查是为了处理命令行参数未提供的情况
    # 在main函数中已经确保了传入的start_date和end_date要么是用户指定的值，要么是DEFAULT值
    # 这里只需要处理空字符串的情况
    if end_date == "":
        end_date = DEFAULT_END_DATE
    if start_date == "":
        start_date = DEFAULT_START_DATE
    
    print(f"使用时间范围: {start_date} 到 {end_date}")
    # Note: Free NewsAPI plan has very limited historical access
    
    state = AgentState(
        messages=[],
        data={
            "tickers": [ticker],
            "start_date": start_date,  # 使用用户提供的开始日期
            "end_date": end_date,      # 使用用户提供的结束日期
            "portfolio": Portfolio(positions={}, total_cash=1000000.0),
            "analyst_signals": {},
        },
        metadata={
            "show_reasoning": True,
            "model_name": "gpt-4",
            "model_provider": "openai",
        },
    )
    
    # First check if API key is set
    if not check_api_key():
        print("\nCannot proceed without a valid API key.")
        return
        
    # Create output directory for CSV files if specified
    if export_csv and output_dir:
        os.makedirs(output_dir, exist_ok=True)
        csv_news_path = os.path.join(output_dir, f"{ticker}_esg_news.csv")
        csv_sentiment_path = os.path.join(output_dir, f"{ticker}_esg_sentiment.csv")
    else:
        csv_news_path = f"{ticker}_esg_news.csv"
        csv_sentiment_path = f"{ticker}_esg_sentiment.csv"
    
    try:
        if use_direct_api:
            # Use the direct API approach instead of the agent
            print(f"Fetching ESG news for {ticker} from {start_date} to {end_date}...")
            try:
                news_items = get_esg_news(
                    ticker=ticker,
                    start_date=start_date,
                    end_date=end_date,
                    export_csv=export_csv,
                    csv_filename=csv_news_path
                )
                
                if news_items:
                    print(f"Found {len(news_items)} ESG-related news items")
                    # 为每日ESG得分创建CSV路径
                    csv_daily_scores_path = os.path.join(output_dir, f"{ticker}_daily_esg_scores.csv") if output_dir else f"{ticker}_daily_esg_scores.csv"
                    
                    sentiment_results = analyze_esg_sentiment(
                        news_items=news_items,
                        export_csv=export_csv,
                        csv_filename=csv_sentiment_path,
                        daily_scores_csv=csv_daily_scores_path
                    )
                    print(f"\nESG情感分析结果:")
                    print(f"总体得分: {sentiment_results['score']:.2f}/10")
                    print(f"详情: {sentiment_results['details']}")
                    
                    # 显示每日ESG得分信息
                    if 'daily_scores' in sentiment_results and sentiment_results['daily_scores']:
                        print(f"\n每日ESG得分 (用于α信号):")
                        print("-" * 50)
                        print(f"{'日期':<12}{'ESG得分':<10}")
                        print("-" * 50)
                        
                        # 按日期排序显示每日得分
                        for date in sorted(sentiment_results['daily_scores'].keys()):
                            score = sentiment_results['daily_scores'][date]
                            print(f"{date:<12}{score:.2f}")
                        
                        print(f"\n每日ESG得分已导出到: {csv_daily_scores_path}")
                    else:
                        print("\n没有可用的每日ESG得分数据")
                else:
                    print("No ESG news found for the specified time range.")
                    print("Try expanding the date range or using a different ticker.")
            except Exception as api_error:
                print(f"Error fetching or processing news: {api_error}")
                print("\nPossible solutions:")
                print("1. Check your internet connection")
                print("2. Verify the API key is correct")
                print("3. The free NewsAPI plan has very limited historical access (usually only the last month)")
                print("4. Try using a different ticker with more news coverage")
        else:
            # Run the full ESG news agent
            print("Running ESG news analysis through agent...")
            result = esg_news_agent(state)
            
            # Access results
            if "analyst_signals" in result["data"] and "esg_news_agent" in result["data"]["analyst_signals"]:
                esg_analysis = result["data"]["analyst_signals"]["esg_news_agent"][ticker]
                print(f"\nESG Analysis Results:")
                print(f"Signal: {esg_analysis['signal']}")
                print(f"Confidence: {esg_analysis['confidence']}%")
                print(f"Reasoning: {esg_analysis['reasoning']}")
            else:
                print("\nESG analysis completed but no signals were generated.")
                print("This may be due to missing API credentials or insufficient data.")
    
    except Exception as e:
        print(f"Error running ESG News Agent: {str(e)}")
        print("\nNote: This may be due to missing API credentials or dependencies.")
        print("Try running the mock demo instead: python src/demo_esg_nvidia_mock.py")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Run ESG News Analysis for NVIDIA")
    parser.add_argument("--use-agent", action="store_true", help="Use the full agent instead of direct API")
    parser.add_argument("--no-csv", action="store_true", help="Disable CSV export")
    parser.add_argument("--output-dir", type=str, help="Directory to save CSV files")
    parser.add_argument("--ticker", type=str, default="NVDA", help="Stock ticker symbol (default: NVDA)")
    parser.add_argument("--start-date", type=str, help="Start date in YYYY-MM-DD format")
    parser.add_argument("--end-date", type=str, help="End date in YYYY-MM-DD format")
    
    args = parser.parse_args()
    
    # 只有当命令行参数明确提供时才使用它们，否则使用默认值
    start_date = args.start_date if args.start_date is not None else DEFAULT_START_DATE
    end_date = args.end_date if args.end_date is not None else DEFAULT_END_DATE
    
    # Run with parsed arguments
    run_esg_agent(
        use_direct_api=not args.use_agent,  # Default is direct API unless --use-agent is specified
        export_csv=not args.no_csv,         # Default is to export CSV unless --no-csv is specified
        output_dir=args.output_dir,         # Optional output directory
        start_date=start_date,              # 使用处理后的开始日期
        end_date=end_date,                  # 使用处理后的结束日期
        ticker=args.ticker                  # Optional ticker symbol
    )

tic = state.get("tic", "BAC")    
ticker = state.get("tic", "BAC")    
csv_path = "NVDA_daily_esg_scores.csv" # 如果你没有指定 # 如果你没有指定 output_dir，可改成 f"{ticker}_daily_esg_scores.csv"
df_esg = pd.read_csv(csv_path, parse_dates=['date'])

# 假设 CSV 长这样：date,score
# 如果列名不是 score，请改成实际列名
# … 你已有的代码 …
df_esg.rename(columns={df_esg.columns[1]: 'esg_score'}, inplace=True)

# 定义从 0–10 分到信号/置信度的映射
def map_signal(esg_score):
    if esg_score >= 7:
        return "BUY"
    elif esg_score <= 3:
        return "SELL"
    else:
        return "NEUTRAL"

# 构造 date→{signal,confidence} 的字典
esg_dict = {}
for _, row in df_esg.iterrows():
    date_str = row['date'].strftime('%Y-%m-%d')
    sig = map_signal(row['esg_score'])
    conf = abs(row['esg_score'] - 5) / 5
    esg_dict[date_str] = {"signal": sig, "confidence": conf}

# **关键：** 外层加上 ticker 这一层
state["esg_signals"] = {
    ticker: esg_dict
}

# （可选）保留 DataFrame，便于调试或可视化
state["esg_signals_df"] = df_esg.set_index('date')

    
#%% combine DataCollectionAgent & DataAnalysisAgent
def run_trading_system():
    agents = [DataCollectionAgent()]
    for agent in agents:
        agent.run(state)

if __name__ == "__main__":
    run_trading_system()
#%%
import pandas as pd
import numpy as np

# ——— 1. 映射函数 ———
def map_signal(esg_score):
    if esg_score >= 7:
        return "BUY"
    elif esg_score <= 3:
        return "SELL"
    else:
        return "NEUTRAL"

def map_conf_level(conf_q):
    if conf_q >= 0.66:
        return "HIGH"
    elif conf_q >= 0.33:
        return "MEDIUM"
    else:
        return "LOW"

# ——— 2. 从 state 构造 esg_dict ———
df_esg = state["esg_signals_df"].copy()
df_esg.index = df_esg.index.normalize()
df_esg["date_str"] = df_esg.index.strftime("%Y-%m-%d")

esg_dict = {}
for _, row in df_esg.iterrows():
    ds     = row["date_str"]
    score  = row["esg_score"]
    sig    = map_signal(score)
    conf_q = abs(score - 5) / 5
    conf   = map_conf_level(conf_q)
    esg_dict[ds] = {"signal": sig, "confidence": conf}

# ——— 3. 准备行情数据 ———
df_daily = state["daily_data"][["Close"]].copy()
df_daily["date_str"] = df_daily.index.normalize().strftime("%Y-%m-%d")
df_daily = df_daily.set_index("date_str")

# ——— 4. 回测仿真：遍历所有 esg_dict 日期 ———
initial_account = state.get("initial_balance", 10_000)
account         = float(state.get("account_balance", initial_account))
position_units  = 0     # 当前持仓股数
buy_price       = None  # 持仓成本价

# 继续用置信度决定动用比例，也可以改为常量
weight_map = {"HIGH":1.0, "MEDIUM":0.5, "LOW":0.25}

records = []
for date_str, info in esg_dict.items():
    if date_str not in df_daily.index:
        continue

    price = df_daily.loc[date_str, "Close"]
    sig   = info["signal"]
    conf  = info["confidence"]
    w     = weight_map[conf]

    change       = 0.0
    profit       = 0.0
    units_traded = 0

    # —— BUY：仅空仓时开仓 —— 
    if sig == "BUY" and position_units == 0:
        budget        = account * w
        units_traded  = int(budget // price)
        if units_traded > 0:
            change         = - units_traded * price
            account       += change
            position_units = units_traded
            buy_price      = price

    # —— SELL：仅有仓位时平仓 —— 
    elif sig == "SELL" and position_units > 0:
        units_traded  = position_units
        change        = units_traded * price
        profit        = units_traded * (price - buy_price)
        account      += change
        position_units = 0
        buy_price      = None

    # NEUTRAL：什么都不做

    records.append({
        "Date":        date_str,
        "Price":       round(price, 2),
        "Signal":      sig,
        "Units":       units_traded,
        "Change($)":   round(change, 2),
        "Account($)":  round(account, 2),
        "Profit($)":   round(profit, 2)
    })

# ——— 5. 构建报告并输出 ———
df_report = pd.DataFrame(records).set_index("Date")
print(df_report)

# 导出到 Excel 或 CSV
# 取当前 state 里的 ticker
ticker = state["tic"]
# 用 f-string 自动拼文件名
out_fname = f"{ticker}_report.xlsx"

try:
    df_report.to_excel(out_fname, index=True)
except PermissionError:
    # 如果 Excel 被占用，就退回写 CSV
    out_fname = out_fname.replace(".xlsx", ".csv")
    df_report.to_csv(out_fname, index=True)

print(f"已导出交易明细: {out_fname}")
    
def construct_daily_equity(state):
    # daily_data：全程每天的收盘价
    df = state["daily_data"][["Close"]].copy().sort_index()
    # trade_history：每笔交易结束时的账户余额
    trades = pd.DataFrame(state["trade_history"])
    trades["date"] = pd.to_datetime(trades["Date"])
    trades = trades.set_index("date").sort_index()

    cash = state["initial_balance"]
    pos  = 0
    eq   = []

    for d, row in df.iterrows():
        # 如果当日有交易，就更新现金 & 持仓
        if d in trades.index:
            rec      = trades.loc[d].iloc[-1]
            cash     = rec["Account($)"]
            pos      = rec["Units"] if rec["Signal"]=="BUY" else 0
        # 当日净值 = 现金 + 持仓 × 当日收盘
        eq.append(cash + pos*row["Close"])
    return pd.Series(eq, index=df.index)

def calc_performance(equity_curve, initial):
    ret = equity_curve.pct_change().dropna()
    ann_ret = (1+ret.mean())**252 - 1
    ann_vol = ret.std() * np.sqrt(252)
    sharpe  = ann_ret / ann_vol if ann_vol else np.nan
    dd      = (equity_curve - equity_curve.cummax()) / equity_curve.cummax()
    max_dd  = dd.min()
    total   = equity_curve.iloc[-1]/initial - 1
    return {
        "total_return": total,
        "annual_return": ann_ret,
        "annual_vol": ann_vol,
        "sharpe_ratio": sharpe,
        "max_drawdown": max_dd
    }



state["trade_history"] = records


import pandas as pd
import matplotlib.pyplot as plt

# ----- 1. 重建 trades DataFrame -----
trades_df = pd.DataFrame(state["trade_history"])
print("trade_history 的列：", trades_df.columns.tolist())

# ----- 2. 转换 Date 列为 datetime，去时区并归一化到日期，然后设为索引 -----
#    假设你的列名是 "Date"，否则改成小写 "date"
trades_df["Date"] = pd.to_datetime(trades_df["Date"]).dt.tz_localize(None).dt.normalize()
trades_df.set_index("Date", inplace=True)
trades_df.sort_index(inplace=True)

# ----- 3. 准备价格序列，并去时区、归一化到日期 -----
price_df = state["daily_data"][["Close"]].copy()
price_df.index = pd.to_datetime(price_df.index).tz_localize(None).normalize()

# ----- 4. 截取我们要画图的时间区间 -----
start = pd.Timestamp("2025-04-10")
end   = pd.Timestamp("2025-05-02")
price_period  = price_df.loc[start:end]
trades_period = trades_df.loc[start:end]

# ----- 5. 提取买卖点 -----
buys  = trades_period[trades_period["Signal"] == "BUY"]
sells = trades_period[trades_period["Signal"] == "SELL"]

# ----- 6. 开始绘图 -----
plt.figure(figsize=(12, 6))
# 绘制收盘价曲线
plt.plot(price_period.index, price_period["Close"], 
         label="Close Price", linewidth=2)
# 绘制买点、卖点
plt.scatter(buys.index,  buys["Price"], marker="^", color="green", s=100, label="BUY")
plt.scatter(sells.index, sells["Price"], marker="v", color="red",   s=100, label="SELL")

# 标题自动带上 ticker 和时间范围
tic = state.get("tic", "TICKER")
plt.title(f"{tic} Price with Buy/Sell Signals ({start.date()} to {end.date()})")
plt.xlabel("Date")
plt.ylabel("Price")
plt.xticks(rotation=45)
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()






























